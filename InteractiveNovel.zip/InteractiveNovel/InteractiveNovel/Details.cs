﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteractiveNovel
{
    internal class Details
    {
        
        public void Title()
        {
            GameIntro();
        }
        public void Password()
        {
            int userPasscode = 123;
            do
            {
                try
                {
                    PassCodeMessage();
                    userPasscode = Convert.ToInt32(Console.ReadLine());
                    if (userPasscode != 123)
                    {
                        PasscodeError();
                    }
                }
                catch (Exception e) { Console.WriteLine(e.Message); }

            }
            while (userPasscode != 123);

        }
        public void PasscodeError()
        {
            Console.WriteLine("Invalid Passcode!");
        }
        
        public void InputError()
        {
            Console.WriteLine("Invalid Input!");
        }
        public void GameWinMessage()
        {
            Console.WriteLine("Congratulations! Your a great player!");
        }
        private void GameIntro()
        {
            Console.WriteLine("BOO! Haunted House");
            Console.WriteLine("************************");
            Console.WriteLine("You awaken in a large house with no items and no memory of how you have gotten here. You hear screams,roars and the unwelcoming sound of silence. You know what you have to do...");
        }
        private void PassCodeMessage()
        {
            Console.WriteLine("Enter passcode: ");
        }
        
    }
}
