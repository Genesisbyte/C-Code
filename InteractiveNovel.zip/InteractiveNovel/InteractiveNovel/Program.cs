﻿using InteractiveNovel;


Hallway stage1 = new Hallway();
Spider stage2 = new Spider();
Details details = new Details();
Spider spider = new Spider();
FinalRoom room = new FinalRoom();

details.Title();
details.Password();
stage1.LevelOne();
spider.SpiderMenu();
room.FinalRoomMenu();