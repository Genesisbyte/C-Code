﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteractiveNovel
{
    internal class FinalRoom
    {
        Details finalDetails = new Details();
        private int userInput;

        public void FinalGame()
        {
            FinalRoomMenu();
            RoomSwitch();
        }
        private void Option1Message()
        {
            Console.WriteLine("You type 1449 with a cautious look on your face. You hear beeping with the sound of gears turning in the room. After a long pause suddenly the floor below you opens as you realise that you have been tanding on a trap door. You were never heard from again.");
            Environment.Exit(0);    
        }
        private void Option2Message()
        {
            Console.WriteLine("You type 2508 with a cautious look on your face. You hear beeping with the sound of gears turning in the room. You think that the keypad is broken but suddenly spikes emerge out of the walls next to you. They are placed so you cannot push back and cannot hide in the middle of them. Try as you might you are unable to escape and succumb to your grisly fate.");
            Environment.Exit(0);
        }
        private void Option3Message()
        {
            Console.WriteLine("You type 6969 with a cautious look on your face. You hear beeping with the sound of gears turning in the room. You begin to chuckle at the numbers provided for some reason, but you haven't noticed that the door has opened with the world open to you. You step out and breathe in the air you have been craving for so long.");
            finalDetails.GameWinMessage();
            Environment.Exit(0);
        
        }
        private void Option4Message()
        {
            Console.WriteLine("You type 2066 with a cautious look on your face. You hear beeping with the sound of gears turning in the room. You wait with thoughts of victory in your mind but you for some reason you start coughing uncontrollably, before you fall unconscious you notice that the room has started filling with noxious fumes. The last memories you have are that you made friends with a giant spider");
            Environment.Exit(0);
        }
        private void Option5Message()
        {
            Console.WriteLine("You gawk at the numbers and decide you aren't doing this anymore. With your mind full of rage you charge at the door, at first you think you have broken down the door but all you have done is break every single bone in your body. You lay there paralyzed unable to move all because you wanted to think outside of the box. What a ridiculous way for your life to end.");
            Environment.Exit(0);
        }
        public void FinalRoomMenu()
        {
            
                    Console.WriteLine("You enter the room with a door with light peering out of the cracks. The exit perhaps? A table lies ahead with four numbers etched on paper: 1449, 2508, 6969,2066. A keypad is on the wall next to the door.");
                    Console.WriteLine("What do you do");
                    Console.WriteLine("1) Enter 1449 into the keypad");
                    Console.WriteLine("2) Enter 2508 into the keypad");
                    Console.WriteLine("3) Enter 6969 into the keypad");
                    Console.WriteLine("4) Enter 2066 into the keypad");
                    Console.WriteLine("5) Try to break down the door");
                    userInput = Convert.ToInt32(Console.ReadLine());
                
                
            
        }
        private void RoomSwitch()
        {
            switch (userInput)
            {
                case 1:
                    Option1Message();
                    break;
                case 2:
                    Option2Message();
                    break;
                case 3:
                    Option3Message();
                    break;
                case 4:
                    Option4Message();
                    break;
                case 5:
                    Option5Message();
                    break;
                default:
                    finalDetails.InputError();
                    break;

            }
        }
    }
}
