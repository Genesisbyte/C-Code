﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace InteractiveNovel
{
    internal class Hallway
    {
        Details gameDetails = new Details();
        private int userInput;
        public void LevelOne()
        {
            HallwayDecision();
            HallwayDoors();
        }

        public void HallwayDoors()
        {
            while (true)
            {
                try
                {
                    HallwayMenu();
                    userInput = Convert.ToInt32(Console.ReadLine());
                    DoorsSwitch();
                    return;
                }
                catch (Exception e) { Console.WriteLine(e.Message); }
            }
        }

        public void HallwayDoorsA()
        {
            WinMessageA();
        }
        private void HallwayDoorsB()
        {
            FailureMessageB();
            Environment.Exit(0);

        }
        private void HallwayDoorsC()
        {
            FailureMessageC();
            Environment.Exit(0);    
            
        }
        private void DoorsSwitch()
        {
                switch (userInput)
                {
                    case 1:
                        HallwayDoorsA();
                        break;
                    case 2:
                        HallwayDoorsB();
                        break;
                    case 3:
                        HallwayDoorsC();
                    break;
                default:
                    gameDetails.InputError();
                    break;
            }
        }
        
        private void FailureMessageC()
        {
            Console.WriteLine("You decide to not go through any doors and begin to question what life means to you." +
                "As you contemplate your existence you realise that you spent too long and begin to wither away from dehydration and starvation." +
                "But hey at least you tried! ");
        }
        private void FailureMessageB()
        {
            Console.WriteLine("You hear nothing until the sound of gears emerge out of the shadows. Suddenly a pain spreads across " +
                "your body, as the light fades from your eyes the last image of your life is a wall of spikes comforting your corpse.");
        }
        private void WinMessageA()
        {
            Console.WriteLine("You go through the left door to face a giant spider!");
        }
        private void HallwayDecision()
        {
            Console.WriteLine("You enter a hallway with two doors facing you.What do you do? ");
        }
        private void HallwayMenu()
        {
            Console.WriteLine("1) Enter left door");
            Console.WriteLine("2) Enter right door");
            Console.WriteLine("3) Ponder what the meaning of life is");
        }
        
    }
}
