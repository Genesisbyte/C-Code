﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteractiveNovel
{
    internal class Spider
    {
        private int userInput;
        Hallway hallway =  new Hallway();
        Details spiderDetails = new Details();
        
        
        public void SpiderMenu()
        {
            Decision();
            SpiderSwitch();
            
            
        }
        private void SpiderSwitch()
        {
            switch (userInput)
            {
                case 1:
                    SpiderFailA();
                    break;
                case 2:
                    SpiderFailB();
                    break;
                case 3:
                    SpiderFailC();
                    break;
                case 4:
                    SpiderEnding();
                    break;
                default:
                    spiderDetails.InputError();
                    break;
            }
        }
        private void SpiderFailA()
        {
            SpiderFailMessage1();
            Environment.Exit(0);

        }
        private void SpiderFailB()
        {
            SpiderFailMessage2();
            Environment.Exit(0);
        }
        private void SpiderFailC()
        {
            SpiderFailMessage3();
            Environment.Exit(0);
        }
        public void SpiderEnding()
        {
            SpiderWinMessage();
        }
        private void SpiderFailMessage1()
        {
            Console.WriteLine("You begin to talk to the spider in an attempt to stop its hostility but you feel like the biggest idiot in the room.The spider does not move which begins to calm you down.Suddenly a itching sensation appears on your body and without any time to think your body bursts with tiny spiders!");
        }
        private void SpiderFailMessage2()
        {
            Console.WriteLine("Without hesitation you sprint to the spider, full of determination you catch it off guard and thinking you are a professional wrestler, you begin to heave the spider but realisation hits and it is clearly too big for you to lift. You cant see it but with a smile on its face the spider knocks you down and begins eating your body.");
        }
        private void SpiderFailMessage3()
        {
            Console.WriteLine("You think if you ignore it it will go away but unfortunately for you, it does not share the same sentiment. It grabs you by the legs and drags you into the darkness never to be seen again.");
        }
        private void SpiderWinMessage()
        {
            Console.WriteLine("No other ideas come to mind and the only thing you can think off is by charming the creature. You prepare for whatever unspeakable plans it has lined up for you but the opposite occurs and it loves you back! You now have a new friend and decides to show you the way to the next room");
        }
        
        private void Decision()
        {
            Console.WriteLine("What do you do?:");
            Console.WriteLine("1) Negotiate with the spider");
            Console.WriteLine("2) Give the spider a suplex");
            Console.WriteLine("3) Do nothing");
            Console.WriteLine("4) Kiss the spider");
            userInput = Convert.ToInt32(Console.ReadLine());
        }
        
    }
}
