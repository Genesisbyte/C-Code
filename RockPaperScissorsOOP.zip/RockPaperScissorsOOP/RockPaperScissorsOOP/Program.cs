﻿// Title: Rock Paper Scissors
// Author: Genesisbyte
// Date: 24-Mar-2024

Game game = new Game();
game.Menu();
game.Play();
game.Result();


class Game
{
    Random rand = new Random();
    private int cpuScore;
    private int userScore;
    private int userInput;
    private int cpuChoice;

    public void Message()
    {
        Console.WriteLine($"PLAYER SCORE {userScore}");
        Console.WriteLine($"CPU SCORE: {cpuScore}");
        Console.WriteLine("Enter 1 for rock. 2 for scissors. 3 for paper ");
    }
    public void Menu()
    {
        Console.WriteLine("Rock Paper Scissors");
        Console.WriteLine("********************");
        Console.WriteLine("1/ Rock");
        Console.WriteLine("2/ Paper");
        Console.WriteLine("3/ Scissors");
    }
    public void switch0()
    {
        if (cpuChoice == 0)
        {
            RockSelection();
            switch (userInput)
            {
                case 1:
                    Console.WriteLine("TIE");
                    break;
                case 2:
                    Console.WriteLine("You win!");
                    userScore++;
                    break;
                case 3:
                    Console.WriteLine("CPU WINS!");
                    cpuScore++;
                    break;

            }
        }
    }
    public void switch1()
    {
        if (cpuChoice == 1)
        {
            PaperSelection();
            switch (userInput)
            {
                case 1:
                    Console.WriteLine("CPU wins!");
                    cpuScore++;
                    break;
                case 2:
                    Console.WriteLine("Draw!");
                    break;
                case 3:
                    Console.WriteLine("You win!");
                    userScore++;
                    break;
            }
        }
    }
    public void switch2()
    {
        if (cpuChoice == 2)
        {
            ScissorsSelection();
            switch (userInput)
            {
                case 1:
                    Console.WriteLine("You win!");
                    userScore++;
                    break;
                case 2:
                    Console.WriteLine("CPU wins!");
                    cpuScore++;
                    break;
                case 3:
                    Console.WriteLine("Draw!");
                    break;
            }
        }
    }
    public void RockSelection()
    {
        Console.WriteLine("CPU SELECTS ROCK!");
    }
    public void PaperSelection()
    {
        Console.WriteLine("CPU SELECTS PAPER!");
    }
    public void ScissorsSelection()
    {
        Console.WriteLine("CPU SELECTS SCISSORS!");
    }
    public void Play()
    {
        while (cpuScore != 5 && userScore != 5)
        {
            Message();
            try
            {
                cpuChoice = rand.Next(0, 3);
                userInput = Convert.ToInt32(Console.ReadLine());

                switch0();
                switch1();
                switch2();
            }

            catch (Exception e) { Console.WriteLine(e.Message); }

        }
    }
    public void Result()
    {
        if (cpuScore == 5)
        {
            Console.WriteLine("CPU WIN!");
        }
        else
        {
            Console.WriteLine("YOU WIN!");
        }
    }

}